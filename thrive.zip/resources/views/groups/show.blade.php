@extends('layouts.app')

@section('content')
  <h2>{{ $group->name }}</h2>



This is my page to show group details.

@endsection
