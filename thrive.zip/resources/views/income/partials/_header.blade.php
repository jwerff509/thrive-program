<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading text-center">
                  <p>Add Details for Person/Household: {{ $person->first_name ." ". $person->last_name }}</p>
                  <p>NRC Number: {{ $person->nrc_number }}</p>
                </div>
