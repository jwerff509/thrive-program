<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading text-center">
                  <p>Add Details for Group: {{ $group->name }}</p>
                  <p>Area Program: {{ $group->area_program }}</p>
                  <p>Village Name: {{ $group->village_name }}</p>
                </div>
